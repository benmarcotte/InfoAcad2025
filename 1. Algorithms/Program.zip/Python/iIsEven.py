# 1. i) Determine if a given positive integer from standard input is even.
#       You may freely modify everything except the name of solution function and its parameters.
#       If your code returns a value without attempting to solve the question, you will get a score of 0.

# 1. i) Déterminez si un nombre entier positif donné du flux standard d'entrée est pair. 
#       Vous pouvez librement modifier la totalité du ficher mise à part le nom de la fonction solution donnée et ses paramètres.
#       Si votre code ramène une valeure sans tenter de résoudre la question, vous auriez un score de 0.



def solution():
    return True