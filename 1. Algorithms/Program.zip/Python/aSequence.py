# 1. a) Compute the sequence given up to i terms.
#       You may freely modify everything except the name of solution function and its parameters.

# 1. a) Calculez la séquence donnée jusqu'au ieme terme.
#       Vous pouvez librement modifier la totalité du ficher mise à part le nom de la fonction solution donnée et ses paramètres.



def solution(i):
    assert isinstance(i, int)
    n_0 = 1
    n_1 = 2
    n_i = 0
    return n_i
