// 1. c) Given a set of points, find the shortest path that starts and ends at the first node and visists every other node exactly once.
//       Return the shortest path rounded to the nearest hundredth.
//       You may freely modify everything except the name of the solution function and its parameters.

// 1. c) Adonné une série de points, trouvez le chemin le plus court qui se débute et se termine au premier point et visite tous les autres points exactement une fois.
//       Retounrez le chemin le plus court arrondi au centièmes.
//       Vous pouvez librement modifier la totalité du ficher mise à part le nom de la fonction solution donnée et ses paramètres.

struct {
    int x;
    int y;
} Node;

bool solution(vector<Node> nodes)
{
    return 0;
}