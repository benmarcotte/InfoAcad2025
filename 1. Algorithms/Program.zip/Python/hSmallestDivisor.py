# 1. h) Return the smallest divisor of an integer from standard input that is larger than 1.
#       The given integer is larger than 1, and the divisor to return must be larger than 1.
#       You may freely modify everything except the name of solution function and its parameters.

# 1. h) Déterminez le plus petit facteur d'un nombre entier du flux stardard d'entrée qui est supérieur à 1.
#       Le nombre donné est supérieur à 1, et le facteur doit être supérieur à 1.
#       Vous pouvez librement modifier la totalité du ficher mise à part le nom de la fonction solution donnée et ses paramètres.



def solution():
    n = int(input())
    assert n > 1
    
    return n